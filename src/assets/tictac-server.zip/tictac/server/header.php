<?php
    if(!isset($res))
        die("ACCESS IS DENIED at: " . __FILE__ . ':' . __LINE__);
?>