<?php

echo "Test";

?>
